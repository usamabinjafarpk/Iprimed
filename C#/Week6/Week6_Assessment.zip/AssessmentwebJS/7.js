// 7.	Given an array of numbers, write a JavaScript function to filter out the even numbers and return a new array with only the odd numbers.
const num = [1, 2, 3, 4, 5, 6, 7, 8, 9];
let a = num.filter((i) => i % 2 != 0);
console.log(a);
