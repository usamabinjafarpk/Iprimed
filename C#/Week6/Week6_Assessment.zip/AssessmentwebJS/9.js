// 9.	Write a JavaScript function that takes an array of numbers and returns a new array with each number squared. Use the map function for this.

const numbers = [1, 2, 3, 4, 5];
let newArr = numbers.map((a)=>a*a);
console.log(newArr);